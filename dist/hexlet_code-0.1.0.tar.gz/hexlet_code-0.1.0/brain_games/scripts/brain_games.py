#!/usr/bin/env python3
import brain_games.cli


def main():
    print("poetry run python -m brain_games.scripts.brain_games")
    print("Welcome to the Brain Games!")

if __name__ == '__main__':
    main()

brain_games.cli.welcome_user()

