### Hexlet tests and linter status:
[![Actions Status](https://github.com/iavalli/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/iavalli/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6c1addaea09c6102d654/maintainability)](https://codeclimate.com/github/iavalli/python-project-49/maintainability)

https://asciinema.org/a/16c8Ls5yIDHSyDVDlUPqYGv2p

