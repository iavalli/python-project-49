EVEN_INSTRUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
ROUNDS_NUMBER = 3
CALC_INSTRUCTION = 'What is the result of the expression?'
MATH_ACTIONS = ('+', '-', '*')
GCD_INSTRUCTION = 'Find the greatest common divisor of given numbers.'
PROGRESSION_INSTRUCTION = 'What number is missing in the progression?'
MIN_PROGR_LENGTH, MAX_PROGR_LENGTH = 7, 12
