EVEN_INSTRUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
ROUNDS_NUMBER = 3
CALC_INSTRUCTION = 'What is the result of the expression?'
MATH_ACTIONS = ('+', '-', '*')
